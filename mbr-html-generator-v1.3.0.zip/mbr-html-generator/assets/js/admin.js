/**
 * MBR HTML Generator — admin script
 *
 * Live HTML mirror of TinyMCE content. Pretty-prints, highlights, copies.
 * Theme preference persists via localStorage.
 */
( function () {
	'use strict';

	if ( typeof window.tinymce === 'undefined' ) {
		return;
	}

	var config = window.mbrHtmlGen || {};
	var i18n   = config.i18n || {};

	if ( config.tinymceBaseUrl ) {
		window.tinymce.baseURL = config.tinymceBaseUrl;
		window.tinymce.suffix  = '.min';
	}

	var STORAGE_THEME   = 'mbrHtmlGen.theme';
	var STORAGE_WRAP    = 'mbrHtmlGen.wrap';
	var STORAGE_FMT     = 'mbrHtmlGen.format';
	var STORAGE_CONTENT = 'mbrHtmlGen.content';
	var SAVE_DEBOUNCE_MS = 500;

	var appEl       = document.getElementById( 'mbr-html-gen-app' );
	var outputEl    = document.getElementById( 'mbr-html-gen-output' );
	var copyBtn     = document.getElementById( 'mbr-html-gen-copy' );
	var downloadBtn = document.getElementById( 'mbr-html-gen-download' );
	var formatBtn   = document.getElementById( 'mbr-html-gen-format' );
	var wrapBtn     = document.getElementById( 'mbr-html-gen-wrap' );
	var clearBtn    = document.getElementById( 'mbr-html-gen-clear' );
	var themeBtn    = document.getElementById( 'mbr-html-gen-theme-toggle' );
	var toastEl     = document.getElementById( 'mbr-html-gen-toast' );
	var charCount   = document.getElementById( 'mbr-html-gen-char-count' );
	var wordCount   = document.getElementById( 'mbr-html-gen-word-count' );
	var lineCount   = document.getElementById( 'mbr-html-gen-line-count' );

	if ( ! appEl ) {
		return;
	}

	var lastRawHtml = '';
	var prettify    = readBool( STORAGE_FMT, true );
	var wrapped     = readBool( STORAGE_WRAP, true );
	var theme       = readString( STORAGE_THEME, 'light' );

	// ---- Storage helpers --------------------------------------------------
	function readBool( key, fallback ) {
		try {
			var v = window.localStorage.getItem( key );
			if ( v === null ) return fallback;
			return v === '1';
		} catch ( e ) { return fallback; }
	}
	function writeBool( key, val ) {
		try { window.localStorage.setItem( key, val ? '1' : '0' ); } catch ( e ) {}
	}
	function readString( key, fallback ) {
		try {
			var v = window.localStorage.getItem( key );
			return v === null ? fallback : v;
		} catch ( e ) { return fallback; }
	}
	function writeString( key, val ) {
		try { window.localStorage.setItem( key, val ); } catch ( e ) {}
	}
	function deleteKey( key ) {
		try { window.localStorage.removeItem( key ); } catch ( e ) {}
	}

	// ---- Debounced content persistence ------------------------------------
	var saveTimer = null;
	function scheduleSave() {
		if ( saveTimer ) {
			clearTimeout( saveTimer );
		}
		saveTimer = setTimeout( function () {
			saveTimer = null;
			if ( lastRawHtml ) {
				writeString( STORAGE_CONTENT, lastRawHtml );
			} else {
				deleteKey( STORAGE_CONTENT );
			}
		}, SAVE_DEBOUNCE_MS );
	}

	// ---- Pretty printer (js-beautify) -------------------------------------
	var BEAUTIFY_OPTS = {
		indent_size:           2,
		indent_char:           ' ',
		wrap_line_length:      0,    // 0 = no auto-wrap; user has Wrap toggle
		preserve_newlines:     true,
		max_preserve_newlines: 1,
		end_with_newline:      false,
		indent_inner_html:     false,
		extra_liners:          [],   // keep output compact
		unformatted:           [ 'code', 'pre' ],
		content_unformatted:   [ 'pre', 'textarea' ]
	};

	function formatHtml( html ) {
		if ( ! html || ! html.replace( /^\s+|\s+$/g, '' ) ) {
			return '';
		}
		// Graceful fallback if js-beautify failed to load for any reason.
		if ( typeof window.html_beautify !== 'function' ) {
			return html;
		}
		try {
			return window.html_beautify( html, BEAUTIFY_OPTS );
		} catch ( e ) {
			return html;
		}
	}

	// ---- Highlighter ------------------------------------------------------
	function escapeHtml( s ) {
		return s
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' );
	}

	function highlight( code ) {
		if ( ! code ) {
			return '<span class="mbr-html-gen-empty">' + escapeHtml( i18n.placeholder || '' ) + '</span>';
		}
		var escaped = escapeHtml( code );

		// Tags with attributes
		escaped = escaped.replace(
			/(&lt;\/?)([a-zA-Z][\w-]*)([^&]*?)(\/?&gt;)/g,
			function ( full, open, tag, attrs, close ) {
				var attrHtml = attrs.replace(
					/([\w:-]+)(=)(&quot;[^&]*?&quot;|&#39;[^&]*?&#39;)/g,
					'<span class="mbr-attr">$1</span><span class="mbr-punct">$2</span><span class="mbr-val">$3</span>'
				);
				return '<span class="mbr-punct">' + open + '</span>' +
					'<span class="mbr-tag">' + tag + '</span>' +
					attrHtml +
					'<span class="mbr-punct">' + close + '</span>';
			}
		);

		// Comments
		escaped = escaped.replace( /(&lt;!--[\s\S]*?--&gt;)/g, '<span class="mbr-comment">$1</span>' );

		return escaped;
	}

	// ---- Render -----------------------------------------------------------
	function render() {
		var display = prettify ? formatHtml( lastRawHtml ) : lastRawHtml;
		outputEl.innerHTML = '<code>' + highlight( display ) + '</code>';
		updateStats( display );
	}

	function updateStats( text ) {
		charCount.textContent = text.length;
		wordCount.textContent = text.replace( /^\s+|\s+$/g, '' ) ? text.replace( /^\s+|\s+$/g, '' ).split( /\s+/ ).length : 0;
		lineCount.textContent = text ? text.split( '\n' ).length : 0;
	}

	// ---- Toast ------------------------------------------------------------
	var toastTimer;
	function showToast( message ) {
		toastEl.textContent = message;
		toastEl.classList.add( 'mbr-show' );
		clearTimeout( toastTimer );
		toastTimer = setTimeout( function () {
			toastEl.classList.remove( 'mbr-show' );
		}, 1600 );
	}

	// ---- Buttons ----------------------------------------------------------
	copyBtn.addEventListener( 'click', function () {
		var text = prettify ? formatHtml( lastRawHtml ) : lastRawHtml;
		copyToClipboard( text ).then( function ( ok ) {
			showToast( ok ? ( i18n.copied || 'Copied' ) : ( i18n.copyFailed || 'Copy failed' ) );
		} );
	} );

	function copyToClipboard( text ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			return navigator.clipboard.writeText( text ).then(
				function () { return true; },
				function () { return fallbackCopy( text ); }
			);
		}
		return Promise.resolve( fallbackCopy( text ) );
	}

	function fallbackCopy( text ) {
		try {
			var ta = document.createElement( 'textarea' );
			ta.value = text;
			ta.setAttribute( 'readonly', '' );
			ta.style.position = 'absolute';
			ta.style.left = '-9999px';
			document.body.appendChild( ta );
			ta.select();
			var ok = document.execCommand( 'copy' );
			document.body.removeChild( ta );
			return ok;
		} catch ( e ) {
			return false;
		}
	}

	// ---- Download ---------------------------------------------------------
	function pad2( n ) { return ( n < 10 ? '0' : '' ) + n; }

	function buildFilename() {
		var d = new Date();
		return 'mbr-html-output-' +
			d.getFullYear() + '-' +
			pad2( d.getMonth() + 1 ) + '-' +
			pad2( d.getDate() ) + '.html';
	}

	if ( downloadBtn ) {
		downloadBtn.addEventListener( 'click', function () {
			var text = prettify ? formatHtml( lastRawHtml ) : lastRawHtml;
			if ( ! text ) {
				return;
			}
			try {
				var blob = new Blob( [ text ], { type: 'text/html;charset=utf-8' } );
				var url  = URL.createObjectURL( blob );
				var a    = document.createElement( 'a' );
				a.href     = url;
				a.download = buildFilename();
				document.body.appendChild( a );
				a.click();
				document.body.removeChild( a );
				setTimeout( function () { URL.revokeObjectURL( url ); }, 1000 );
				showToast( i18n.downloaded || 'File downloaded' );
			} catch ( e ) {
				showToast( i18n.copyFailed || 'Download failed' );
			}
		} );
	}

	formatBtn.addEventListener( 'click', function () {
		prettify = ! prettify;
		formatBtn.setAttribute( 'aria-pressed', prettify ? 'true' : 'false' );
		writeBool( STORAGE_FMT, prettify );
		render();
	} );

	wrapBtn.addEventListener( 'click', function () {
		wrapped = ! wrapped;
		outputEl.classList.toggle( 'mbr-html-gen-wrap-on', wrapped );
		wrapBtn.setAttribute( 'aria-pressed', wrapped ? 'true' : 'false' );
		writeBool( STORAGE_WRAP, wrapped );
	} );

	clearBtn.addEventListener( 'click', function () {
		// Wipe persisted content immediately, plus any pending debounced save.
		if ( saveTimer ) {
			clearTimeout( saveTimer );
			saveTimer = null;
		}
		deleteKey( STORAGE_CONTENT );
		lastRawHtml = '';
		if ( window.tinymce && window.tinymce.activeEditor ) {
			window.tinymce.activeEditor.setContent( '' );
			window.tinymce.activeEditor.focus();
		}
	} );

	themeBtn.addEventListener( 'click', function () {
		theme = theme === 'dark' ? 'light' : 'dark';
		applyTheme();
		writeString( STORAGE_THEME, theme );
		initEditor();
	} );

	function applyTheme() {
		appEl.setAttribute( 'data-theme', theme );
	}

	// ---- TinyMCE ----------------------------------------------------------
	function initEditor() {
		if ( window.tinymce.activeEditor ) {
			lastRawHtml = window.tinymce.activeEditor.getContent();
			window.tinymce.remove( '#mbr-html-gen-editor' );
		}

		window.tinymce.init( {
			selector:                   '#mbr-html-gen-editor',
			license_key:                'gpl',
			height:                     '100%',
			menubar:                    'edit insert view format table',
			branding:                   false,
			promotion:                  false,
			skin:                       theme === 'dark' ? 'oxide-dark' : 'oxide',
			content_css:                theme === 'dark' ? 'dark' : 'default',
			plugins:                    'advlist anchor autolink charmap codesample directionality emoticons fullscreen help image insertdatetime link lists media nonbreaking pagebreak preview quickbars searchreplace table visualblocks visualchars wordcount',
			toolbar:                    'undo redo | blocks | bold italic underline strikethrough | forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media table | preview',
			quickbars_selection_toolbar: 'bold italic | quicklink h2 h3 blockquote',
			content_style:              "body { font-family: 'Geist', -apple-system, sans-serif; font-size: 14px; line-height: 1.6; padding: 18px; }",
			setup: function ( editor ) {
				var update = function () {
					lastRawHtml = editor.getContent();
					render();
					scheduleSave();
				};
				editor.on( 'input keyup change SetContent ExecCommand NodeChange', update );
				editor.on( 'init', function () {
					// Restore previous session if present and the in-memory copy is empty.
					if ( ! lastRawHtml ) {
						var saved = readString( STORAGE_CONTENT, '' );
						if ( saved ) {
							lastRawHtml = saved;
						}
					}
					if ( lastRawHtml ) {
						editor.setContent( lastRawHtml );
					}
					update();
				} );
			}
		} );
	}

	// ---- Multi-tab sync ---------------------------------------------------
	// If another tab edits the content, mirror it here. Last-write-wins.
	window.addEventListener( 'storage', function ( e ) {
		if ( e.key !== STORAGE_CONTENT || ! window.tinymce || ! window.tinymce.activeEditor ) {
			return;
		}
		var incoming = e.newValue || '';
		if ( incoming === lastRawHtml ) {
			return;
		}
		// Cancel any pending local save so we don't clobber the incoming value.
		if ( saveTimer ) {
			clearTimeout( saveTimer );
			saveTimer = null;
		}
		lastRawHtml = incoming;
		// setContent triggers the SetContent event, which calls update() and
		// schedules a (no-op) save of the same value — harmless.
		window.tinymce.activeEditor.setContent( incoming );
	} );

	// Flush any pending debounced save before the page is hidden/closed.
	window.addEventListener( 'beforeunload', function () {
		if ( saveTimer ) {
			clearTimeout( saveTimer );
			saveTimer = null;
			if ( lastRawHtml ) {
				writeString( STORAGE_CONTENT, lastRawHtml );
			} else {
				deleteKey( STORAGE_CONTENT );
			}
		}
	} );

	// ---- Boot -------------------------------------------------------------
	formatBtn.setAttribute( 'aria-pressed', prettify ? 'true' : 'false' );
	wrapBtn.setAttribute( 'aria-pressed', wrapped ? 'true' : 'false' );
	outputEl.classList.toggle( 'mbr-html-gen-wrap-on', wrapped );
	applyTheme();
	render();
	initEditor();

} )();
